//# allFunctionsCalledOnLoad
import{n as e,t}from"./peerTypeSection-D5ldojMC.js";var n=e(e=>{e.scrollable.append(t(`video`,`AutoDownloadVideosTitle`,e.middlewareHelper.get()))});export{n as default};
//# sourceMappingURL=video-D2VKvTpQ.js.map