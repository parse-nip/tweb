//# allFunctionsCalledOnLoad
function e(e){if(e||(e=window.event),e){e=e.originalEvent||e;try{e.stopPropagation&&e.stopPropagation(),e.preventDefault&&e.preventDefault(),e.returnValue=!1,e.cancelBubble=!0}catch{}}return!1}export{e as t};
//# sourceMappingURL=cancelEvent-Bs2qkQ0q.js.map