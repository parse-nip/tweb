//# allFunctionsCalledOnLoad
import{u as e}from"./web-FH1QzTRi.js";import{o as t}from"./sticker-DeEQFurc.js";import{U as n}from"./confirmationPopup-Dr3IsD-H.js";import{t as r}from"./folderTitle-Bh-kfjb5.js";function i(i){return e(()=>n(r(i.title,t().get(),!0,{textColor:i.textColor})))}export{i as t};
//# sourceMappingURL=folderTitleTsx-DvkxGdom.js.map