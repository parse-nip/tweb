//# allFunctionsCalledOnLoad
import{O as e}from"./renderer-BoaeX621.js";function t(t){return Array.from(t.childNodes).map(t=>t.nodeType===t.TEXT_NODE?e(t.textContent):t.outerHTML).join(``)}export{t};
//# sourceMappingURL=documentFragmentToHTML-tYif4yGv.js.map