//# allFunctionsCalledOnLoad
import{r as e}from"./toast-uBw_7tQs.js";function t(t,n){t?.type!==`MIDDLEWARE`&&(console.error(n,t),e({langPackKey:`Error.AnError`}))}export{t};
//# sourceMappingURL=toastError-D1IcxaTH.js.map