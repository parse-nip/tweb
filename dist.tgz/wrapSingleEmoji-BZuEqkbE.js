//# allFunctionsCalledOnLoad
import{h as e}from"./apiManagerProxy-DZwZtjf7.js";import{u as t}from"./renderer-BoaeX621.js";function n(n){return t(n,{entities:[e(n)]})}export{n as t};
//# sourceMappingURL=wrapSingleEmoji-BZuEqkbE.js.map