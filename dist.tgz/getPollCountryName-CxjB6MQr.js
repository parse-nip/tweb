//# allFunctionsCalledOnLoad
import{u as e}from"./langPack-CpcJKV8D.js";function t(t){if(t?.toUpperCase()===`FT`)return`Fragment`;let n=e.countriesList.find(e=>e.iso2.toLowerCase()===t?.toLowerCase());return n?e.format(n.default_name,!0):t}export{t};
//# sourceMappingURL=getPollCountryName-CxjB6MQr.js.map