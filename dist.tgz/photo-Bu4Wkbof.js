//# allFunctionsCalledOnLoad
import{n as e,t}from"./peerTypeSection-D5ldojMC.js";var n=e(e=>{e.scrollable.append(t(`photo`,`AutoDownloadPhotosTitle`,e.middlewareHelper.get()))});export{n as default};
//# sourceMappingURL=photo-Bu4Wkbof.js.map